// Registro de PWA.
